package com.ds.lab;
import java.lang.*;
import java.util.*;

class SegmentTree {
    private Node[] nodeArray;

    SegmentTree(int [] array, int n) {
        int temp = (int) (Math.ceil(Math.log(n) / Math.log(2)));
        int size = 2 * (int) (Math.pow(2, temp)) - 1;
        nodeArray = new Node[size];
        createSegmentTree(array, 0, n - 1, 0);
    }

    private static int getMid(int start, int end) {
        return start + (end - start) / 2;
    }

    private Node createSegmentTree(int[] array, int start, int end, int index) {
        if (start == end) {
            nodeArray[index] = new Node(true);
            nodeArray[index].maximum = nodeArray[index].minimum = nodeArray[index].totalSum = array[start];
            nodeArray[index].startIndex = nodeArray[index].endIndex = start;
            return nodeArray[index];
        }
        int mid = getMid(start, end);
        nodeArray[index] = new Node(false);
        Node left = createSegmentTree(array, start, mid, 2 * index + 1);
        Node right = createSegmentTree(array, mid + 1, end, 2 * index + 2);
        nodeArray[index].totalSum = left.totalSum + right.totalSum;
        nodeArray[index].minimum = Math.min(left.minimum, right.minimum);
        nodeArray[index].maximum = Math.max(left.maximum, right.maximum);
        nodeArray[index].startIndex = start;
        nodeArray[index].endIndex = end;
        return nodeArray[index];
    }

    int recursiveMinimum(int start, int end, int index) {
        if ((nodeArray[index].startIndex >= start) && (nodeArray[index].endIndex <= end))
            return nodeArray[index].minimum;

        if ((end < nodeArray[index].startIndex) || (start > nodeArray[index].endIndex))
            return Integer.MAX_VALUE;

        return Math.min(recursiveMinimum(start, end, 2 * index + 1), recursiveMinimum(start, end, 2 * index + 2));
    }

    int recursiveMaximum(int start, int end, int index) {
        if ((nodeArray[index].startIndex >= start) && (nodeArray[index].endIndex <= end))
            return nodeArray[index].maximum;

        if ((end < nodeArray[index].startIndex) || (start > nodeArray[index].endIndex))
            return Integer.MIN_VALUE;

        return Math.max(recursiveMaximum(start, end, 2 * index + 1), recursiveMaximum(start, end, 2 * index + 2));
    }

    int recursiveSum(int start, int end, int index) {
        if ((nodeArray[index].startIndex >= start) && (nodeArray[index].endIndex <= end))
            return nodeArray[index].totalSum;

        if ((end < nodeArray[index].startIndex) || (start > nodeArray[index].endIndex))
            return 0;

        return recursiveSum(start, end, 2 * index + 1) + recursiveSum(start, end, 2 * index + 2);
    }

    Node updateSegmentTree(int start, int end, int index) {
        if ((end < nodeArray[index].startIndex) || (start > nodeArray[index].endIndex))
            return nodeArray[index];
        if (nodeArray[index].startIndex == nodeArray[index].endIndex) {
            nodeArray[index].maximum = nodeArray[index].minimum = nodeArray[index].totalSum += 4;
            return nodeArray[index];
        }
        Node left = updateSegmentTree(start, end, 2 * index + 1);
        Node right = updateSegmentTree(start, end, 2 * index + 2);
        nodeArray[index].totalSum = left.totalSum + right.totalSum;
        nodeArray[index].minimum = Math.min(left.minimum, right.minimum);
        nodeArray[index].maximum = Math.max(left.maximum, right.maximum);
        return nodeArray[index];
    }

    void printSegmentTree() {
        for (Node node : nodeArray) {
            if (node == null)
                System.out.print("* ");
            else
                System.out.print(node.minimum + " ");
        }
    }
}

class Node {
    int minimum, maximum, totalSum;
    int startIndex, endIndex;

    Node(boolean isLeaf) {
    }
}

class Main {
    private static int bruteForceSum(int[] array, int start, int end) {
        int summation = 0;
        for (int i = start; i <= end; i++) {
            summation += array[i];
        }
        return summation;
    }

    private static int bruteForceMin(int[] array, int start, int end) {
        int minimum = array[start];
        for (int i = start + 1; i <= end; i++) {
            if (array[i] < minimum)
                minimum = array[i];
        }
        return minimum;
    }

    private static int bruteForceMax(int[] array, int start, int end) {
        int maximum = array[start];
        for (int i = start + 1; i <= end; i++) {
            if (array[i] > maximum)
                maximum = array[i];
        }
        return maximum;
    }

    private static boolean verifyIndexForArray(int n, int start, int end) {
        return !((start < 0) || (end > n - 1) || (start > end));
    }

    private static void updateSuppliedArrayByBruteForce(int[] array, int start, int end) {
        for (int i = start; i <= end; i++)
            array[i] += 4;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("number of values in array:");
        int n = sc.nextInt();
        System.out.print("values:");
        int[] array = new int[n];
        for (int i = 0; i < n; i++)
            array[i] = sc.nextInt();

        SegmentTree tree = new SegmentTree(array, n);
        while (true) {
            System.out.println("Menu:\n1:Maximum Value\n2:Minimum Value\n3:Sum\n4:Add 4\n5:Exit");
            int value = sc.nextInt();
            if ((value < 1) || (value > 5)) {
                System.out.println("index error");
                continue;
            }
            if (value == 5) {
                sc.close();
                System.exit(0);
            }
            System.out.println("1:Brute Force and 2:Segment Tree");
            int algoWay = sc.nextInt();
            if ((algoWay < 1) || (algoWay > 2)) {
                System.out.println("wrong input");
                continue;
            }
            long startT, endT;
            System.out.println("enter start and end index.");
            int start = sc.nextInt();
            int end = sc.nextInt();
            if (!verifyIndexForArray(n, start, end)) {
                System.out.println("index error");
                continue;
            }
            switch (value) {
                case 1: {
                    if (algoWay == 1) {
                        startT = System.nanoTime();
                        int max = bruteForceMax(array, start, end);
                        endT = System.nanoTime();
                        System.out.print("max value : " + max + "\nexecution time = " + (endT - startT) + " ns\n");
                    } else {
                        startT = System.nanoTime();
                        int max = tree.recursiveMaximum(start, end, 0);
                        endT = System.nanoTime();
                        System.out.print("max value : " + max + "\nexecution time = " + (endT - startT) + " ns\n");
                    }
                    break;
                }

                case 2: {
                    if (algoWay == 1) {
                        startT = System.nanoTime();
                        int min = bruteForceMin(array, start, end);
                        endT = System.nanoTime();
                        System.out.print("Min value : " + min + "\nExecution time = " + (endT - startT) + " ns\n");
                    } else {
                        startT = System.nanoTime();
                        int min = tree.recursiveMinimum(start, end, 0);
                        endT = System.nanoTime();
                        System.out.print("Min value : " + min + "\nExecution time = " + (endT - startT) + " ns\n");
                    }
                    break;
                }

                case 3: {
                    if (algoWay == 1) {
                        startT = System.nanoTime();
                        int sum = bruteForceSum(array, start, end);
                        endT = System.nanoTime();
                        System.out.print("Sum : " + sum + "\nExecution time = " + (endT - startT) + " ns\n");
                    } else {
                        startT = System.nanoTime();
                        int sum = tree.recursiveSum(start, end, 0);
                        endT = System.nanoTime();
                        System.out.print("Sum : " + sum + "\nExecution time = " + (endT - startT) + " ns\n");
                    }
                    break;
                }

                case 4: {
                    if (algoWay == 1) {
                        startT = System.nanoTime();
                        updateSuppliedArrayByBruteForce(array, start, end);
                        endT = System.nanoTime();
                        System.out.print("Execution time = " + (endT - startT) + " ns\n");
                        tree.updateSegmentTree(start, end, 0);
                        tree.printSegmentTree();
                    } else {
                        startT = System.nanoTime();
                        tree.updateSegmentTree(start, end, 0);
                        endT = System.nanoTime();
                        System.out.print("Execution time = " + (endT - startT) + " ns\n");
                        updateSuppliedArrayByBruteForce(array, start, end);
                        tree.printSegmentTree();
                    }
                    break;
                }
            }
        }
    }
}