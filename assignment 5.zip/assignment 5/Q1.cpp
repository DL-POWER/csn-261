/*!
  @file Q1.cpp 
  @brief Solution for Q1 L5.
  @author Pramod
  @date 10/2/2019
*/


#include <iostream> 
using namespace std; 
  


/// A[] represents coefficients of first polynomial 
/// B[] represents coefficients of second polynomial 
/// m and n are sizes of A[] and B[] respectively 

/*!
this method will mutiply two polynomials stored i9n array and give new array corresponding to new polynomial
@param int A[]
@param int B[]
@param int m
@param int n
@author Pramod
@date 10/2/2019

*/
int *multiply(int A[], int B[], int m, int n) 
{ 
   int *prod = new int[m+n-1]; 
  
   /// Initialize the porduct polynomial 
   for (int i = 0; i<m+n-1; i++) 
     prod[i] = 0; 
  
   /// Multiply two polynomials term by term 
  
   /// Take ever term of first polynomial 
   for (int i=0; i<m; i++) 
   { 
     /// Multiply the current term of first polynomial 
     /// with every term of second polynomial. 
     for (int j=0; j<n; j++) 
         prod[i+j] += A[i]*B[j]; 
   } 
  
   return prod; 
} 
/*!
this method will add two polynomials stored i9n array and give new array corresponding to new polynomial
@param int A[]
@param int B[]
@param int m
@param int n
@author Pramod
@date 10/2/2019

*/

int *add(int A[], int B[], int m, int n) 
{  int big = m;
  int small = n;
   int *add = new int[max(m,n)]; 
   if(m<n){
    big = n;
    small = m;
   }
   int diff = big - small;

   /// Initialize the porduct polynomial 
   for (int i = 0; i<big; i++) 
     add[i] = 0; 
  
   /// Multiply two polynomials term by term 
  
   /// Take ever term of first polynomial 
   for (int i=0; i<small; i++) 
   { 
      add[i] = A[i]+B[i];
   } 
   if(m>n){
    for (int i=small;i<big; i++) 
    { 
      add[i] = A[i];
    }
  }
  else{
    for (int i=small;i<big; i++) 
    { 
      add[i] = B[i];
    }
  }



   return add; 
}
  
/*!
this method will print the polynomial
@param int poly[] base address of polynomial
@param int max  no. of possible non zero cofficents in array
@author Pramod
@date 10/2/2019

*/ 
void printPoly(int poly[], int n) 
{ 
    for (int i=0; i<n; i++) 
    { 
       cout << poly[i]; 
       if (i != 0) 
        cout << "x^" << i ; 
       if (i != n-1) 
       cout << " + "; 
    } 
} 

/*!
this method will print the polynomial
@param int poly[] base address of polynomial
@param int max  no. of possible non zero cofficents in array
@author Pramod
@date 10/2/2019

*/ 
void printpol(int poly[], int n)
{
  for (int i=0; i<n; i++) 
    { 
       cout << poly[n-1-i]<<"      "<<n-1-i<<endl; 
    }
}
  
/// Driver program to test above functions 

/*!
main
@author Pramod
@date 10/2/2019

*/ 
int main() 
{   
    int M,N,m,n,temp;
    cout<<"enter degree of polynomial 1st: "<<endl;
    cin>>M;
    cout<<"enter degree of polynomial 2nd: "<<endl;
    cin>>N;
    /// The following array represents polynomial 
    m = M+1;
    n = N+1;
    int A[m]; 
    cout<<"enter coefficients of 1st polynomial "<<endl;
    for (int i = 0; i < m; ++i)
     {
       
      cin>>temp;
      A[M-i] = temp;
     } 
    int B[N];
     cout<<"enter coefficients of 2nd polynomial "<<endl;
    for (int i = 0; i < n; ++i)
     {
       
      cin>>temp;
      B[N-i] = temp;
     } 
  
    /// The following array represents polynomial 1 + 2x + 4x^2  
  
    cout << "First polynomial is "<<endl; 
    printpol(A, m); 
    cout<<endl;
    cout << "Second polynomial is "<<endl; 
    printpol(B, n); 
    cout<<endl;

  
    int *prod = multiply(A, B, m, n); 
    int *added = add(A, B, m, n);
    cout << "Product polynomial is "<<endl; 
    printpol(prod, m+n-1); 
    cout<<endl;
    cout << "added polynomial is "<<endl; 
    printpol(added, max(m,n));
  
    return 0; 
}